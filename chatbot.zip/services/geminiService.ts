
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { MODELS } from "../constants";

export const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateChatResponse = async (
  prompt: string, 
  history: { role: 'user' | 'model'; parts: { text: string }[] }[] = [],
  useSearch = true
) => {
  const ai = getAi();
  const config: any = {
    temperature: 0.7,
  };

  if (useSearch) {
    config.tools = [{ googleSearch: {} }];
  }

  const response = await ai.models.generateContent({
    model: MODELS.CHAT,
    contents: [
      ...history,
      { role: 'user', parts: [{ text: prompt }] }
    ],
    config
  });

  return {
    text: response.text || '',
    groundingMetadata: response.candidates?.[0]?.groundingMetadata
  };
};

export const generateImage = async (prompt: string) => {
  const ai = getAi();
  const response = await ai.models.generateContent({
    model: MODELS.IMAGE,
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  const images: string[] = [];
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      images.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
    }
  }
  return images;
};

// Audio encoding/decoding as per guidelines
export function decodeBase64(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encodeBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioBuffer(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
