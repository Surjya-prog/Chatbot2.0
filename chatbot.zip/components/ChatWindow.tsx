
import React, { useState, useRef, useEffect } from 'react';
import { Icons } from '../constants';
import { Message } from '../types';
import { generateChatResponse } from '../services/geminiService';

interface ChatWindowProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#1e1e21] relative">
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8 pb-32"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center space-y-6 opacity-60">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center">
              <Icons.Sparkles />
            </div>
            <h1 className="text-3xl font-semibold text-white">How can I help you today?</h1>
            <div className="grid grid-cols-2 gap-4 max-w-xl">
              {["Write a story", "Help with code", "Analyze data", "General knowledge"].map(item => (
                <button 
                  key={item}
                  onClick={() => setInput(item)}
                  className="px-6 py-4 rounded-2xl bg-[#2d2d35] hover:bg-[#3f3f4a] text-sm text-left transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}
          >
            <div className={`max-w-3xl flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 shrink-0 rounded-full flex items-center justify-center text-sm font-bold ${msg.role === 'user' ? 'bg-blue-600' : 'bg-purple-600'}`}>
                {msg.role === 'user' ? 'U' : 'G'}
              </div>
              <div className={`space-y-4 px-1 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                <div className={`rounded-2xl px-5 py-3 text-base leading-relaxed ${msg.role === 'user' ? 'bg-[#2d2d35] text-white' : 'text-gray-200'}`}>
                  {msg.content}
                  {msg.imageUrls?.map((url, i) => (
                    <img key={i} src={url} alt="Generated" className="mt-4 rounded-xl max-w-sm border border-[#2d2d35]" />
                  ))}
                </div>
                {msg.groundingUrls && msg.groundingUrls.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {msg.groundingUrls.map((link, idx) => (
                      <a 
                        key={idx}
                        href={link.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs px-2 py-1 bg-[#2d2d35] hover:bg-blue-900/30 text-blue-400 rounded transition-colors"
                      >
                        {link.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start animate-pulse">
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-purple-600/50 flex items-center justify-center">
                <Icons.Sparkles />
              </div>
              <div className="h-10 w-24 bg-[#2d2d35] rounded-2xl"></div>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#1e1e21] via-[#1e1e21] to-transparent">
        <div className="max-w-4xl mx-auto">
          <form 
            onSubmit={handleSubmit}
            className="relative flex items-center"
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Message Gemini..."
              rows={1}
              className="w-full bg-[#2d2d35] text-white rounded-3xl py-4 pl-6 pr-16 focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none custom-scrollbar"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="absolute right-3 p-3 text-white bg-blue-600 hover:bg-blue-500 rounded-2xl disabled:opacity-50 disabled:bg-[#3f3f4a] transition-all"
            >
              <Icons.Send />
            </button>
          </form>
          <p className="text-center text-[10px] text-gray-500 mt-2">
            Gemini can make mistakes. Check important info.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
