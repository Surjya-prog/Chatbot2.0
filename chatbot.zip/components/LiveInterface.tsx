
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Icons } from '../constants';
import { getAi, encodeBase64, decodeBase64, decodeAudioBuffer } from '../services/geminiService';
import { LiveServerMessage, Modality } from '@google/genai';

const LiveInterface: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState('Standby');
  const [transcriptions, setTranscriptions] = useState<string[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const startSession = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = getAi();
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setStatus('Listening');
            setIsActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encodeBase64(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000'
              };
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              const outputCtx = audioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioBuffer(decodeBase64(base64Audio), outputCtx);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.onended = () => sourcesRef.current.delete(source);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              setStatus('Speaking');
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setStatus('Listening');
            }

            if (message.serverContent?.turnComplete) {
              setStatus('Listening');
            }

            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setTranscriptions(prev => [...prev, `Gemini: ${text}`].slice(-5));
            }
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setTranscriptions(prev => [...prev, `You: ${text}`].slice(-5));
            }
          },
          onerror: (e) => {
            console.error('Session Error:', e);
            setStatus('Error');
            stopSession();
          },
          onclose: () => {
            setStatus('Standby');
            setIsActive(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: 'You are a helpful, conversational companion. Speak concisely and naturally.'
        }
      });
      
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Microphone Error:', err);
      setStatus('Permission Denied');
    }
  };

  const stopSession = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    setIsActive(false);
    setStatus('Standby');
  }, []);

  useEffect(() => {
    return () => stopSession();
  }, [stopSession]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-[#0e0e11] p-10">
      <div className="relative w-64 h-64 flex items-center justify-center">
        {isActive && (
          <>
            <div className="recording-ring opacity-20"></div>
            <div className="recording-ring opacity-40 delay-300"></div>
            <div className="recording-ring opacity-60 delay-700"></div>
          </>
        )}
        <div className={`w-40 h-40 rounded-full flex items-center justify-center z-10 transition-all duration-500 ${isActive ? 'bg-red-500 scale-110 shadow-[0_0_50px_rgba(239,68,68,0.3)]' : 'bg-[#2d2d35]'}`}>
          <div className="text-white transform scale-150">
            <Icons.Mic />
          </div>
        </div>
      </div>

      <div className="mt-12 text-center space-y-4">
        <h2 className="text-2xl font-semibold text-white tracking-wide">{status}</h2>
        <p className="text-gray-400 max-w-md mx-auto">
          {isActive ? 'Gemini is listening. You can speak naturally.' : 'Press the button below to start a live voice conversation.'}
        </p>
      </div>

      <div className="mt-12 w-full max-w-lg space-y-2">
        {transcriptions.map((t, i) => (
          <div key={i} className="text-sm py-1 border-b border-white/5 text-gray-300">
            {t}
          </div>
        ))}
      </div>

      <div className="mt-16">
        {!isActive ? (
          <button 
            onClick={startSession}
            className="px-10 py-4 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-all transform hover:scale-105 active:scale-95 flex items-center gap-3"
          >
            <Icons.Mic />
            Connect Voice
          </button>
        ) : (
          <button 
            onClick={stopSession}
            className="px-10 py-4 bg-red-600 text-white font-semibold rounded-full hover:bg-red-700 transition-all transform hover:scale-105 active:scale-95 flex items-center gap-3"
          >
            <div className="w-3 h-3 bg-white rounded-sm"></div>
            Disconnect
          </button>
        )}
      </div>
    </div>
  );
};

export default LiveInterface;
