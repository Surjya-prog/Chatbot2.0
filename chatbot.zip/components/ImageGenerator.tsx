
import React, { useState } from 'react';
import { Icons } from '../constants';
import { generateImage } from '../services/geminiService';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const result = await generateImage(prompt);
      setImages(prev => [...result, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#131314] p-8">
      <div className="max-w-6xl mx-auto space-y-12">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold text-white tracking-tight">Nebula Studio</h1>
          <p className="text-gray-400">Bring your ideas to life with advanced image generation.</p>
        </div>

        <div className="bg-[#1e1e21] rounded-3xl p-6 border border-white/5 shadow-2xl">
          <div className="flex flex-col md:flex-row gap-4">
            <input 
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe what you want to create... (e.g., 'A futuristic neon city in a rainstorm')"
              className="flex-1 bg-[#2d2d35] text-white rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
            />
            <button 
              onClick={handleGenerate}
              disabled={isLoading || !prompt.trim()}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold rounded-2xl hover:opacity-90 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <Icons.Sparkles />
              )}
              Generate
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-20">
          {images.map((img, i) => (
            <div key={i} className="group relative aspect-square rounded-2xl overflow-hidden bg-[#1e1e21] border border-white/5">
              <img src={img} alt="Generated" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button 
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = img;
                    link.download = `nebula-image-${Date.now()}.png`;
                    link.click();
                  }}
                  className="p-3 bg-white/10 backdrop-blur-md rounded-xl hover:bg-white/20 text-white"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                </button>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="aspect-square rounded-2xl bg-[#1e1e21] border border-white/5 animate-pulse flex flex-col items-center justify-center text-gray-500 gap-3">
              <Icons.Image />
              <span className="text-xs">Generating masterpiece...</span>
            </div>
          )}
          {images.length === 0 && !isLoading && (
            <div className="col-span-full py-32 text-center text-gray-600">
              <Icons.Sparkles />
              <p className="mt-4">Your creations will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;
