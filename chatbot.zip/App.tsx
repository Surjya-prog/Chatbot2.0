
import React, { useState, useCallback, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import LiveInterface from './components/LiveInterface';
import ImageGenerator from './components/ImageGenerator';
import { ViewType, ChatSession, Message } from './types';
import { generateChatResponse } from './services/geminiService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>(ViewType.CHAT);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  // Initialize first session
  useEffect(() => {
    const id = Date.now().toString();
    const initialSession: ChatSession = {
      id,
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now()
    };
    setSessions([initialSession]);
    setActiveSessionId(id);
  }, []);

  const handleNewChat = useCallback(() => {
    const id = Date.now().toString();
    const newSession: ChatSession = {
      id,
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(id);
    setCurrentView(ViewType.CHAT);
  }, []);

  const handleSendMessage = async (text: string) => {
    if (!activeSessionId) return;
    
    setIsLoading(true);
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now()
    };

    // Update session state with user message
    setSessions(prev => prev.map(s => {
      if (s.id === activeSessionId) {
        return {
          ...s,
          title: s.messages.length === 0 ? text.slice(0, 30) + '...' : s.title,
          messages: [...s.messages, userMsg]
        };
      }
      return s;
    }));

    try {
      const activeSession = sessions.find(s => s.id === activeSessionId);
      const history = activeSession?.messages.map(m => ({
        role: m.role === 'user' ? 'user' as const : 'model' as const,
        parts: [{ text: m.content }]
      })) || [];

      const response = await generateChatResponse(text, history);
      
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        timestamp: Date.now(),
        groundingUrls: response.groundingMetadata?.groundingChunks?.map((c: any) => ({
          uri: c.web?.uri || c.maps?.uri,
          title: c.web?.title || c.maps?.title || 'Source'
        })).filter(Boolean)
      };

      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, assistantMsg] };
        }
        return s;
      }));
    } catch (err) {
      console.error(err);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Sorry, I encountered an error processing your request. Please check your connection and try again.",
        timestamp: Date.now()
      };
      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, errorMsg] };
        }
        return s;
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const currentSession = sessions.find(s => s.id === activeSessionId);

  return (
    <div className="flex h-screen bg-[#0e0e11] text-[#e5e7eb] select-none">
      <Sidebar 
        currentView={currentView}
        setView={setCurrentView}
        sessions={sessions}
        activeSessionId={activeSessionId}
        setActiveSession={setActiveSessionId}
        onNewChat={handleNewChat}
      />
      
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {currentView === ViewType.CHAT && (
          <ChatWindow 
            messages={currentSession?.messages || []} 
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
          />
        )}
        {currentView === ViewType.LIVE && (
          <LiveInterface />
        )}
        {currentView === ViewType.IMAGES && (
          <ImageGenerator />
        )}
      </main>
    </div>
  );
};

export default App;
