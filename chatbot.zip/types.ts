
export enum ViewType {
  CHAT = 'CHAT',
  LIVE = 'LIVE',
  IMAGES = 'IMAGES'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  groundingUrls?: Array<{ uri: string; title: string }>;
  imageUrls?: string[];
  isThinking?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}
